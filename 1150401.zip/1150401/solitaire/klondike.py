import random
from typing import List, Optional, Tuple

SUITS = ['♠', '♥', '♦', '♣']
RANK_NAMES = {1: 'A', 11: 'J', 12: 'Q', 13: 'K'}


class Card:
    def __init__(self, rank: int, suit: str):
        self.rank = rank
        self.suit = suit

    def __str__(self):
        return RANK_NAMES.get(self.rank, str(self.rank)) + self.suit

    def color(self) -> str:
        return 'red' if self.suit in ('♥', '♦') else 'black'


class Deck:
    def __init__(self):
        self.cards: List[Card] = [Card(r, s) for s in SUITS for r in range(1, 14)]
        random.shuffle(self.cards)

    def draw(self) -> Optional[Card]:
        return self.cards.pop() if self.cards else None


class KlondikeGame:
    def __init__(self, draw_count: int = 1, redeals: int = 3):
        self.draw_count = draw_count
        self.redeals = redeals
        self.reset()

    def reset(self):
        deck = Deck()
        # tableau: 7 piles; each card is tuple (Card, face_up:bool)
        self.tableau: List[List[Tuple[Card, bool]]] = []
        for i in range(7):
            pile = []
            for j in range(i + 1):
                c = deck.draw()
                pile.append((c, j == i))
            self.tableau.append(pile)

        # foundations: 4 piles for suits
        self.foundations: dict = {s: [] for s in SUITS}
        # stock and waste
        self.stock: List[Card] = deck.cards
        deck.cards = []
        self.waste: List[Card] = []
        self.score = 0
        # redeal control
        self.redeals_remaining = self.redeals

    def draw(self):
        # draw draw_count cards
        if not self.stock:
            return None
        take = min(self.draw_count, len(self.stock))
        for _ in range(take):
            self.waste.append(self.stock.pop())
        return self.waste[-1] if self.waste else None

    def recycle_waste_to_stock(self) -> bool:
        """Move waste back to stock (reversing order) if redeals remain."""
        if not self.waste:
            return False
        if self.redeals_remaining <= 0:
            return False
        self.stock = list(reversed(self.waste))
        self.waste = []
        self.redeals_remaining -= 1
        # 回收棄牌扣分
        self.score -= 1
        return True

    def can_move_to_tableau(self, card: Card, dest_pile: List[Tuple[Card, bool]]) -> bool:
        if not dest_pile:
            return card.rank == 13  # only King to empty pile
        top, face = dest_pile[-1]
        return (top.rank == card.rank + 1) and (top.color() != card.color())

    def can_move_to_foundation(self, card: Card) -> bool:
        pile = self.foundations[card.suit]
        if not pile:
            return card.rank == 1
        return pile[-1].rank + 1 == card.rank

    def move_tableau_to_tableau(self, src_idx: int, card_pos: int, dst_idx: int) -> bool:
        src = self.tableau[src_idx]
        if card_pos < 0 or card_pos >= len(src):
            return False
        card, face = src[card_pos]
        if not face:
            return False
        moving_seq = src[card_pos:]
        if not moving_seq:
            return False
        if not all(face for _, face in moving_seq):
            return False
        if self.can_move_to_tableau(moving_seq[0][0], self.tableau[dst_idx]):
            # perform move
            self.tableau[dst_idx].extend(moving_seq)
            del self.tableau[src_idx][card_pos:]
            # flip new top if needed
            if self.tableau[src_idx] and not self.tableau[src_idx][-1][1]:
                c, _ = self.tableau[src_idx][-1]
                self.tableau[src_idx][-1] = (c, True)
                # 翻牌扣分
                self.score -= 1
            self.score += 5 * len(moving_seq)
            return True
        return False

    def move_waste_to_tableau(self, dst_idx: int) -> bool:
        if not self.waste:
            return False
        card = self.waste[-1]
        if self.can_move_to_tableau(card, self.tableau[dst_idx]):
            self.tableau[dst_idx].append((card, True))
            self.waste.pop()
            self.score += 5
            return True
        return False

    def flip_tableau_top(self, idx: int) -> bool:
        """Flip the top card of tableau pile `idx` (if face-down). Deduct 1 point."""
        if idx < 0 or idx >= len(self.tableau):
            return False
        pile = self.tableau[idx]
        if not pile:
            return False
        card, face = pile[-1]
        if face:
            return False
        pile[-1] = (card, True)
        self.score -= 1
        return True

    def move_waste_to_foundation(self) -> bool:
        if not self.waste:
            return False
        card = self.waste[-1]
        if self.can_move_to_foundation(card):
            self.foundations[card.suit].append(card)
            self.waste.pop()
            self.score += 10
            return True
        return False

    def move_tableau_to_foundation(self, src_idx: int) -> bool:
        if not self.tableau[src_idx]:
            return False
        card, face = self.tableau[src_idx][-1]
        if not face:
            return False
        if self.can_move_to_foundation(card):
            self.foundations[card.suit].append(card)
            self.tableau[src_idx].pop()
            if self.tableau[src_idx] and not self.tableau[src_idx][-1][1]:
                c, _ = self.tableau[src_idx][-1]
                self.tableau[src_idx][-1] = (c, True)
                # 翻牌扣分
                self.score -= 1
            self.score += 10
            return True
        return False

    def is_won(self) -> bool:
        return all(len(pile) == 13 for pile in self.foundations.values())

    def has_moves(self) -> bool:
        """Return True if any legal move, draw, or recycle is available."""
        # if any card can be moved to foundation from waste
        if self.waste:
            if self.can_move_to_foundation(self.waste[-1]):
                return True
        # if stock available to draw
        if self.stock:
            return True
        # if recycle available
        if self.waste and self.redeals_remaining > 0:
            return True

        # waste to tableau
        if self.waste:
            wcard = self.waste[-1]
            for pile in self.tableau:
                if self.can_move_to_tableau(wcard, pile):
                    return True

        # tableau top to foundation
        for pile in self.tableau:
            if pile:
                card, face = pile[-1]
                if face and self.can_move_to_foundation(card):
                    return True

        # tableau to tableau (any face-up sequence)
        for i, src in enumerate(self.tableau):
            for pos in range(len(src)):
                card, face = src[pos]
                if not face:
                    continue
                # try move this sequence to any other pile
                for j, dst in enumerate(self.tableau):
                    if i == j:
                        continue
                    if self.can_move_to_tableau(card, dst):
                        return True

        return False

    def status(self) -> str:
        return f"分數: {self.score} | 牌堆: {len(self.stock)} | 棄牌: {len(self.waste)}"

    def to_dict(self) -> dict:
        def card_to_dict(c: Card):
            return {'rank': c.rank, 'suit': c.suit}

        return {
            'draw_count': self.draw_count,
            'redeals': self.redeals,
            'redeals_remaining': self.redeals_remaining,
            'tableau': [
                [({'card': card_to_dict(card), 'face': face}) for (card, face) in pile]
                for pile in self.tableau
            ],
            'foundations': {s: [card_to_dict(c) for c in pile] for s, pile in self.foundations.items()},
            'stock': [card_to_dict(c) for c in self.stock],
            'waste': [card_to_dict(c) for c in self.waste],
            'score': self.score,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'KlondikeGame':
        def dict_to_card(d):
            return Card(d['rank'], d['suit'])

        g = cls(draw_count=data.get('draw_count', 1), redeals=int(data.get('redeals', 3)))
        # rebuild tableau
        g.tableau = []
        for pile in data.get('tableau', []):
            newpile = []
            for item in pile:
                c = dict_to_card(item['card'])
                newpile.append((c, bool(item['face'])))
            g.tableau.append(newpile)

        # foundations
        g.foundations = {s: [dict_to_card(c) for c in pile] for s, pile in data.get('foundations', {}).items()}

        # stock & waste
        g.stock = [dict_to_card(c) for c in data.get('stock', [])]
        g.waste = [dict_to_card(c) for c in data.get('waste', [])]

        g.score = int(data.get('score', 0))
        # restore redeals_remaining if provided
        g.redeals_remaining = int(data.get('redeals_remaining', g.redeals))
        return g
