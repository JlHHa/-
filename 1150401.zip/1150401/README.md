# Pyramid Solitaire（金字塔接龍）

簡易文字版金字塔接龍（Pyramid Solitaire）實作。

玩法重點：
- 建立一個 7 層金字塔（共 28 張卡），剩餘為牌堆（stock）。
- 可以移除兩張露出的金字塔卡，若點數合計為 13（K 單獨移除）。
- 可從牌堆抽至棄牌（waste），棄牌頂端可與金字塔卡配對移除。

快速開始：

1. 啟動虛擬環境（如果有）

```powershell
python -m venv env
env\Scripts\activate
```

2. 執行遊戲：

```powershell
python play.py
```

常用指令：`show`, `draw`, `remove r1,c1 r2,c2`, `removew r,c`, `removek r,c`, `help`, `quit`。

座標採 0-based，格式為 `row,col`，例如最底下一排的第一張為 `6,0`。

- 將 CLI 改成圖形介面（tkinter 或 web）？
- 加入自動回收棄牌、紀錄得分或其他接龍規則（例如 Klondike）？
- 或是改成其他接龍規則（如 Klondike）？
 
已新增功能：
- 自動回收棄牌（redeal）機制，預設重洗次數為 3，可於 `PyramidGame(redeals=2)` 指定。
- 得分系統：移除每張卡片得 100 分（配對移除兩張則 +200）。
- 新增示範腳本 `run_demo.py`，可自動執行一次遊戲流程以驗證回收與得分。

執行示範：

```powershell
python run_demo.py
```

新的 Klondike（Windows 風格）實作：
- 新增遊戲邏輯檔案 `solitaire/klondike.py`（Klondike 規則、tableau、foundations、stock/waste）。
- 新增 GUI 程式 `gui_klondike.py`（點選式操作：抽牌、選擇牌列、移動到其他牌列或基礎堆、AutoFound）。

要啟動 Klondike GUI：

```powershell
python gui_klondike.py
```
- 將 CLI 改成圖形介面（tkinter 或 web）？
- 加入自動重置棄牌牌堆功能？
- 或是改成其他接龍規則（如 Klondike）？
