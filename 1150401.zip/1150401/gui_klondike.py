import tkinter as tk
from tkinter import messagebox
from solitaire.klondike import KlondikeGame


CARD_W = 80
CARD_H = 110
X_GAP = 20
Y_GAP = 30


class KlondikeGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title('Windows 風格接龍')
        self.game = KlondikeGame(draw_count=1, redeals=3)
        self.ended = False

        # controls
        ctrl = tk.Frame(root)
        ctrl.pack(fill='x', padx=6, pady=6)
        tk.Button(ctrl, text='抽牌', command=self.on_draw).pack(side='left')
        tk.Button(ctrl, text='自動移至基礎堆', command=self.on_auto_found).pack(side='left')
        tk.Button(ctrl, text='回收棄牌', command=self.on_recycle).pack(side='left')
        tk.Button(ctrl, text='儲存', command=self.on_save).pack(side='left')
        tk.Button(ctrl, text='載入', command=self.on_load).pack(side='left')
        tk.Button(ctrl, text='儲存最高分', command=self.on_save_highscore).pack(side='left')
        tk.Button(ctrl, text='重新開始', command=self.on_restart).pack(side='left')

        self.save_file = 'klondike_save.json'
        self.highscore_file = 'klondike_highscore.json'
        self.highscore = self.load_highscore()

        self.status_var = tk.StringVar()
        tk.Label(root, textvariable=self.status_var).pack()
        # 顯示訊息（例如回收/儲存結果）
        self.msg_var = tk.StringVar()
        tk.Label(root, textvariable=self.msg_var).pack()

        # canvas for cards
        self.canvas = tk.Canvas(root, width=1000, height=600, bg='green')
        self.canvas.pack(padx=6, pady=6)

        # layout coordinates
        self.found_x = [600 + i * (CARD_W + 10) for i in range(4)]
        self.found_y = 20
        self.stock_x = 20
        self.stock_y = 20
        self.waste_x = 120
        self.waste_y = 20
        self.table_x = [20 + i * (CARD_W + X_GAP) for i in range(7)]
        self.table_y = 160

        # drag state
        self.drag_items = []
        self.drag_offset = (0, 0)
        self.drag_src = None  # ('table', ti, pos) or ('waste',)

        # bindings
        self.canvas.bind('<ButtonPress-1>', self.on_press)
        self.canvas.bind('<B1-Motion>', self.on_motion)
        self.canvas.bind('<ButtonRelease-1>', self.on_release)

        self.draw_all()

    def draw_card(self, x, y, card, face_up=True, tag=None):
        if not face_up:
            rect = self.canvas.create_rectangle(x, y, x + CARD_W, y + CARD_H, fill='blue', outline='black')
            txt = self.canvas.create_text(x + CARD_W / 2, y + CARD_H / 2, text='XX', fill='white')
        else:
            color = 'red' if card.color() == 'red' else 'black'
            rect = self.canvas.create_rectangle(x, y, x + CARD_W, y + CARD_H, fill='white', outline='black')
            txt1 = self.canvas.create_text(x + 12, y + 14, anchor='nw', text=str(card), fill=color, font=('TkDefaultFont', 10, 'bold'))
            txt2 = self.canvas.create_text(x + CARD_W - 12, y + CARD_H - 14, anchor='se', text=str(card), fill=color, font=('TkDefaultFont', 10, 'bold'))
            # group id list
            self.canvas.addtag_withtag('card', rect)
            self.canvas.addtag_withtag('card', txt1)
            self.canvas.addtag_withtag('card', txt2)
        ids = self.canvas.find_enclosed(x - 1, y - 1, x + CARD_W + 1, y + CARD_H + 1)
        if tag:
            for i in ids:
                self.canvas.addtag_withtag(tag, i)
        return ids

    def draw_all(self):
        self.canvas.delete('all')
        # foundations
        suits = ['♠', '♥', '♦', '♣']
        for i, s in enumerate(suits):
            x = self.found_x[i]
            y = self.found_y
            pile = self.game.foundations[s]
            if pile:
                card = pile[-1]
                self.draw_card(x, y, card, True, tag=f'found_{s}')
            else:
                # empty slot
                self.canvas.create_rectangle(x, y, x + CARD_W, y + CARD_H, fill='darkgreen', outline='white')
                self.canvas.create_text(x + CARD_W / 2, y + CARD_H / 2, text=s, fill='white')

        # stock
        sx, sy = self.stock_x, self.stock_y
        if self.game.stock:
            self.canvas.create_rectangle(sx, sy, sx + CARD_W, sy + CARD_H, fill='blue', outline='black')
            self.canvas.create_text(sx + CARD_W / 2, sy + CARD_H / 2, text=str(len(self.game.stock)), fill='white')
        else:
            self.canvas.create_rectangle(sx, sy, sx + CARD_W, sy + CARD_H, fill='darkgreen', outline='white')
            self.canvas.create_text(sx + CARD_W / 2, sy + CARD_H / 2, text='空', fill='white')

        # waste
        wx, wy = self.waste_x, self.waste_y
        if self.game.waste:
            card = self.game.waste[-1]
            ids = self.draw_card(wx, wy, card, True, tag='waste')
        else:
            self.canvas.create_rectangle(wx, wy, wx + CARD_W, wy + CARD_H, fill='darkgreen', outline='white')
            self.canvas.create_text(wx + CARD_W / 2, wy + CARD_H / 2, text='棄牌', fill='white')

        # tableau
        for i in range(7):
            tx = self.table_x[i]
            pile = self.game.tableau[i]
            y = self.table_y
            for p_idx, (card, face) in enumerate(pile):
                tag = f'table_{i}_{p_idx}'
                if face:
                    self.draw_card(tx, y + p_idx * Y_GAP, card, True, tag=tag)
                else:
                    self.draw_card(tx, y + p_idx * Y_GAP, card, False, tag=tag)

        self.status_var.set(self.game.status())
        # 置中顯示最高分與重洗次數
        try:
            rr = self.game.redeals_remaining
        except Exception:
            rr = 0
        cx = int(self.canvas['width']) // 2
        # 顯示最高分與重洗次數
        try:
            hs = int(self.highscore)
        except Exception:
            hs = 0
        self.canvas.create_text(cx, 14, text=f'最高分：{hs}', fill='yellow', font=('TkDefaultFont', 12, 'bold'))
        self.canvas.create_text(cx, 36, text=f'重洗次數剩餘：{rr}', fill='white', font=('TkDefaultFont', 12, 'bold'))
        # 檢查勝利或無法繼續
        self.check_end()

    def find_tag_at(self, x, y):
        items = self.canvas.find_overlapping(x, y, x, y)
        for it in items[::-1]:
            tags = self.canvas.gettags(it)
            for t in tags:
                if t.startswith('table_') or t == 'waste' or t.startswith('found_'):
                    return t
        return None

    def on_press(self, event):
        tag = self.find_tag_at(event.x, event.y)
        if not tag:
            return
        if tag == 'waste':
            if not self.game.waste:
                return
            # prepare drag of waste top
            self.drag_src = ('waste',)
            self.drag_items = self.canvas.find_withtag('waste')
        elif tag.startswith('table_'):
            parts = tag.split('_')
            ti = int(parts[1])
            pos = int(parts[2])
            # only allow dragging if face up
            pile = self.game.tableau[ti]
            card, face = pile[pos]
            if not face:
                # if top card, flip
                if pos == len(pile) - 1:
                    # 使用遊戲方法翻牌以便扣分
                    self.game.flip_tableau_top(ti)
                    self.draw_all()
                return
            # collect all tags for sequence starting at pos
            self.drag_src = ('table', ti, pos)
            tag_prefix = f'table_{ti}_'
            # find canvas items for all cards in sequence
            self.drag_items = []
            for p in range(pos, len(pile)):
                self.drag_items.extend(self.canvas.find_withtag(f'table_{ti}_{p}'))
        else:
            return
        # compute offset
        self.drag_offset = (event.x, event.y)
        for it in self.drag_items:
            self.canvas.tag_raise(it)

    def on_motion(self, event):
        if not self.drag_items:
            return
        dx = event.x - self.drag_offset[0]
        dy = event.y - self.drag_offset[1]
        for it in self.drag_items:
            self.canvas.move(it, dx, dy)
        self.drag_offset = (event.x, event.y)

    def on_release(self, event):
        if not self.drag_items or not self.drag_src:
            self.drag_items = []
            self.drag_src = None
            return
        # determine drop column by x
        drop_x = event.x
        drop_y = event.y
        # check foundations
        for i, s in enumerate(['♠', '♥', '♦', '♣']):
            fx = self.found_x[i]
            fy = self.found_y
            if fx <= drop_x <= fx + CARD_W and fy <= drop_y <= fy + CARD_H:
                # drop to foundation
                if self.drag_src[0] == 'waste':
                    ok = self.game.move_waste_to_foundation()
                else:
                    _, ti, pos = self.drag_src
                    if pos != len(self.game.tableau[ti]) - 1:
                        ok = False
                    else:
                        ok = self.game.move_tableau_to_foundation(ti)
                self.draw_all()
                self.drag_items = []
                self.drag_src = None
                return
        # check tableau columns
        for i, tx in enumerate(self.table_x):
            ty = self.table_y
            if tx - CARD_W/2 <= drop_x <= tx + CARD_W/2 + CARD_W and ty - 20 <= drop_y <= 600:
                # drop to tableau i
                if self.drag_src[0] == 'waste':
                    ok = self.game.move_waste_to_tableau(i)
                else:
                    _, src_ti, src_pos = self.drag_src
                    ok = self.game.move_tableau_to_tableau(src_ti, src_pos, i)
                self.draw_all()
                self.drag_items = []
                self.drag_src = None
                return

        # otherwise, cancel (redraw to reset positions)
        self.draw_all()
        self.drag_items = []
        self.drag_src = None

    def on_draw(self):
        card = self.game.draw()
        if card is None:
            # try auto-recycle if possible
            if getattr(self.game, 'recycle_waste_to_stock', None):
                if self.game.redeals_remaining > 0 and self.game.waste:
                    ok = self.game.recycle_waste_to_stock()
                    if ok:
                        self.msg_var.set('已回收棄牌到牌堆')
                        card = self.game.draw()
        self.draw_all()

    def on_save(self):
        import json
        data = self.game.to_dict()
        try:
            with open(self.save_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            # 已儲存遊戲狀態（不紀錄最高分）
            self.msg_var.set('已儲存遊戲')
        except Exception as e:
            self.msg_var.set('儲存失敗: ' + str(e))
        self.draw_all()

    def on_load(self):
        import json
        try:
            with open(self.save_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.game = KlondikeGame.from_dict(data)
            self.msg_var.set('已載入遊戲')
        except Exception as e:
            self.msg_var.set('載入失敗: ' + str(e))
        self.draw_all()

    def on_recycle(self):
        # explicit user-initiated recycle
        if getattr(self.game, 'recycle_waste_to_stock', None):
            if self.game.redeals_remaining > 0 and self.game.waste:
                ok = self.game.recycle_waste_to_stock()
                self.msg_var.set('回收成功' if ok else '回收失敗')
            else:
                self.msg_var.set('無可回收的棄牌或回合已用完')
        else:
            self.msg_var.set('此版本不支援回收')
        self.draw_all()

    def check_end(self):
        # avoid repeating dialogs
        if self.ended:
            return
        if self.game.is_won():
            try:
                messagebox.showinfo('遊戲勝利', '恭喜，你已將所有牌移至基礎堆！')
            except Exception:
                pass
            self.ended = True
            return
        # no moves left
        if not self.game.has_moves():
            try:
                messagebox.showinfo('遊戲結束', '目前沒有可行動的牌，遊戲結束。')
            except Exception:
                pass
            self.ended = True
            return

    def load_highscore(self) -> int:
        import json, os
        try:
            if os.path.exists(self.highscore_file):
                with open(self.highscore_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return int(data.get('highscore', 0))
        except Exception:
            pass
        return 0

    def on_save_highscore(self):
        """手動儲存目前分數（若大於既有最高分則更新）。"""
        import json
        try:
            cur = int(getattr(self.game, 'score', 0))
        except Exception:
            cur = 0
        try:
            prev = int(self.highscore)
        except Exception:
            prev = 0
        if cur > prev:
            self.highscore = cur
            try:
                with open(self.highscore_file, 'w', encoding='utf-8') as f:
                    json.dump({'highscore': self.highscore}, f, ensure_ascii=False, indent=2)
                self.msg_var.set('已儲存最高分')
            except Exception as e:
                self.msg_var.set('儲存最高分失敗: ' + str(e))
        else:
            self.msg_var.set('目前分數未超越最高分，未變更')
        self.draw_all()

    def on_auto_found(self):
        moved = True
        while moved:
            moved = False
            if self.game.move_waste_to_foundation():
                moved = True
            for i in range(7):
                if self.game.move_tableau_to_foundation(i):
                    moved = True
        self.draw_all()

    def on_restart(self):
        self.game.reset()
        self.draw_all()


def main():
    root = tk.Tk()
    app = KlondikeGUI(root)
    root.mainloop()


if __name__ == '__main__':
    main()
