from pyramid_solitaire.pyramid import PyramidGame


def find_free_king(game: PyramidGame):
    for r in range(len(game.pyramid)):
        for c in range(len(game.pyramid[r])):
            if game.is_free(r, c):
                card = game.pyramid[r][c]
                if card and card.value() == 13:
                    return (r, c)
    return None


def find_free_pair(game: PyramidGame):
    # naive search for any free pair summing to 13
    free = []
    for r in range(len(game.pyramid)):
        for c in range(len(game.pyramid[r])):
            if game.is_free(r, c):
                card = game.pyramid[r][c]
                if card:
                    free.append(((r, c), card))
    n = len(free)
    for i in range(n):
        for j in range(i + 1, n):
            if free[i][1].value() + free[j][1].value() == 13:
                return free[i][0], free[j][0]
    return None


def demo():
    game = PyramidGame(redeals=2)
    print('初始布局:')
    print(game.pyramid_str())
    print(game.status_str())

    # Draw all cards to exhaust stock and trigger recycle
    draws = 0
    while True:
        card = game.draw()
        draws += 1
        if card is None:
            print('無法再抽，牌堆已空且無重洗')
            break
        if draws % 10 == 0:
            # print intermittent status
            print(f'已抽 {draws} 張：', game.status_str())
        if not game.stock and game.waste and game.redeals_remaining > 0:
            print('觸發自動回收棄牌為新牌堆')

    print('抽牌結束，嘗試自動移除可移除的配對（簡易策略）')

    moved = True
    while moved:
        moved = False
        pair = find_free_pair(game)
        if pair:
            ok = game.remove_pair(pair[0], pair[1])
            if ok:
                print(f'移除配對 {pair[0]} & {pair[1]}，分數: {game.score}')
                moved = True
                continue
        k = find_free_king(game)
        if k:
            if game.remove_king(k[0], k[1]):
                print(f'移除 K at {k}，分數: {game.score}')
                moved = True

    print('最後狀態:')
    print(game.pyramid_str())
    print(game.status_str())
    print('是否勝利:', game.won())


if __name__ == '__main__':
    demo()
