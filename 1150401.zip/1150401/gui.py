import tkinter as tk
from tkinter import messagebox
from pyramid_solitaire.pyramid import PyramidGame


class PyramidGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title('Pyramid Solitaire')
        self.game = PyramidGame()
        self.selected = []  # list of (r,c) or ('waste',)

        # top frame for controls
        ctrl = tk.Frame(root)
        ctrl.pack(padx=6, pady=6)

        tk.Button(ctrl, text='Draw', command=self.on_draw).grid(row=0, column=0)
        tk.Button(ctrl, text='Remove Pair', command=self.on_remove_pair).grid(row=0, column=1)
        tk.Button(ctrl, text='Use Waste', command=self.on_use_waste).grid(row=0, column=2)
        tk.Button(ctrl, text='Remove King', command=self.on_remove_king).grid(row=0, column=3)
        tk.Button(ctrl, text='Remove Waste K', command=self.on_remove_waste_king).grid(row=0, column=4)
        tk.Button(ctrl, text='Restart', command=self.on_restart).grid(row=0, column=5)

        # status labels
        self.status_var = tk.StringVar()
        tk.Label(root, textvariable=self.status_var).pack()

        # pyramid frame
        self.pyr_frame = tk.Frame(root)
        self.pyr_frame.pack(padx=6, pady=6)

        # waste and stock
        bottom = tk.Frame(root)
        bottom.pack(pady=6)
        tk.Label(bottom, text='Waste:').grid(row=0, column=0)
        self.waste_btn = tk.Button(bottom, text='--', width=6, command=self.on_select_waste)
        self.waste_btn.grid(row=0, column=1)
        tk.Label(bottom, text='Stock:').grid(row=0, column=2)
        self.stock_lbl = tk.Label(bottom, text='0')
        self.stock_lbl.grid(row=0, column=3)

        self.msg_var = tk.StringVar()
        tk.Label(root, textvariable=self.msg_var, fg='blue').pack()

        self.card_buttons = {}  # (r,c) -> button
        self.build_pyramid_ui()
        self.update_ui()

    def build_pyramid_ui(self):
        # create buttons for each potential position (7 rows)
        for r in range(7):
            for c in range(r + 1):
                btn = tk.Button(self.pyr_frame, text='   ', width=6, command=lambda rr=r, cc=c: self.on_click_card(rr, cc))
                btn.grid(row=r, column=c + (6 - r))
                self.card_buttons[(r, c)] = btn

    def on_click_card(self, r, c):
        if not self.game.is_free(r, c):
            self.msg_var.set('該卡未被解除封鎖')
            return
        coord = (r, c)
        if coord in self.selected:
            self.selected.remove(coord)
        else:
            self.selected.append(coord)
        self.update_ui()

    def on_select_waste(self):
        key = ('waste',)
        if not self.game.waste:
            self.msg_var.set('棄牌為空')
            return
        if key in self.selected:
            self.selected.remove(key)
        else:
            self.selected.append(key)
        self.update_ui()

    def on_draw(self):
        card = self.game.draw()
        if card:
            self.msg_var.set(f'抽到 {card}')
        else:
            self.msg_var.set('無法抽牌（無重洗）')
        self.update_ui()

    def on_remove_pair(self):
        if len(self.selected) != 2:
            self.msg_var.set('請選兩張金字塔卡作為配對')
            return
        a, b = self.selected
        if a == ('waste',) or b == ('waste',):
            self.msg_var.set('請使用 "Use Waste" 按鈕來與棄牌配對')
            return
        ok = self.game.remove_pair(a, b)
        if ok:
            self.msg_var.set('配對移除成功')
        else:
            self.msg_var.set('無法移除，檢查是否為可移除卡或合計13')
        self.selected = []
        self.update_ui()

    def on_use_waste(self):
        # expect one pyramid coord selected and waste selected
        pyr = [s for s in self.selected if s != ('waste',)]
        if len(pyr) != 1 or ('waste',) not in self.selected:
            self.msg_var.set('請選一張金字塔卡並選擇棄牌')
            return
        r, c = pyr[0]
        ok = self.game.remove_with_waste(r, c)
        if ok:
            self.msg_var.set('使用棄牌移除成功')
        else:
            self.msg_var.set('移除失敗，可能點數不合或該卡不可移除')
        self.selected = []
        self.update_ui()

    def on_remove_king(self):
        if len(self.selected) != 1 or self.selected[0] == ('waste',):
            self.msg_var.set('請選一張金字塔的 K (13) 來移除')
            return
        r, c = self.selected[0]
        ok = self.game.remove_king(r, c)
        if ok:
            self.msg_var.set('K 移除成功')
        else:
            self.msg_var.set('無法移除 K')
        self.selected = []
        self.update_ui()

    def on_remove_waste_king(self):
        ok = self.game.remove_waste_king()
        if ok:
            self.msg_var.set('已移除棄牌頂端的 K')
        else:
            self.msg_var.set('棄牌頂端不是 K 或棄牌為空')
        self.selected = []
        self.update_ui()

    def on_restart(self):
        self.game = PyramidGame()
        self.selected = []
        self.msg_var.set('已重新開始')
        self.update_ui()

    def update_ui(self):
        # update pyramid buttons
        for (r, c), btn in self.card_buttons.items():
            card = self.game.pyramid[r][c]
            if card is None:
                btn.config(text=' . ', state='disabled', relief='flat')
            else:
                label = str(card)
                if not self.game.is_free(r, c):
                    btn.config(text=label, state='disabled', relief='raised')
                else:
                    btn.config(text=label, state='normal', relief='raised')
            if (r, c) in self.selected:
                btn.config(bg='lightgreen')
            else:
                btn.config(bg='SystemButtonFace')

        # update waste and stock
        self.waste_btn.config(text=str(self.game.waste[-1]) if self.game.waste else '--')
        if ('waste',) in self.selected:
            self.waste_btn.config(bg='lightgreen')
        else:
            self.waste_btn.config(bg='SystemButtonFace')
        self.stock_lbl.config(text=str(len(self.game.stock)))

        # status
        self.status_var.set(self.game.status_str())


def main():
    root = tk.Tk()
    app = PyramidGUI(root)
    root.mainloop()


if __name__ == '__main__':
    main()
