import random
from typing import List, Optional, Tuple


RANK_NAMES = {1: 'A', 11: 'J', 12: 'Q', 13: 'K'}


class Card:
    def __init__(self, rank: int, suit: str):
        self.rank = rank  # 1..13
        self.suit = suit

    def __str__(self):
        name = RANK_NAMES.get(self.rank, str(self.rank))
        return f"{name}{self.suit}"

    def value(self) -> int:
        return self.rank


class Deck:
    SUITS = ['♠', '♥', '♦', '♣']

    def __init__(self):
        self.cards: List[Card] = [Card(r, s) for s in Deck.SUITS for r in range(1, 14)]
        random.shuffle(self.cards)

    def draw(self) -> Optional[Card]:
        return self.cards.pop() if self.cards else None

    def __len__(self):
        return len(self.cards)


class PyramidGame:
    def __init__(self, redeals: int = 3):
        deck = Deck()
        # build pyramid: 7 rows (0..6) totaling 28 cards
        self.pyramid: List[List[Optional[Card]]] = []
        for r in range(7):
            row: List[Optional[Card]] = []
            for c in range(r + 1):
                row.append(deck.draw())
            self.pyramid.append(row)

        # remaining cards are stock
        self.stock: List[Card] = deck.cards
        deck.cards = []
        self.waste: List[Card] = []
        # gameplay state
        self.redeals = redeals
        self.redeals_remaining = redeals
        self.score = 0

    def draw(self) -> Optional[Card]:
        if not self.stock:
            # try auto-recycle waste to stock if redeals remaining
            if not self.recycle_waste_to_stock():
                return None
        card = self.stock.pop()
        self.waste.append(card)
        return card

    def recycle_waste_to_stock(self) -> bool:
        """If possible, move waste back to stock (reversing order) and consume a redeal."""
        if not self.waste:
            return False
        if self.redeals_remaining <= 0:
            return False
        # Move waste back to stock preserving draw order
        self.stock = self.waste[::-1]
        self.waste = []
        self.redeals_remaining -= 1
        return True

    def is_free(self, r: int, c: int) -> bool:
        # A card is free if no card covers it: either it's on last row
        # or both positions (r+1,c) and (r+1,c+1) are None
        if not (0 <= r < len(self.pyramid) and 0 <= c <= r):
            return False
        if self.pyramid[r][c] is None:
            return False
        if r == len(self.pyramid) - 1:
            return True
        below_left = self.pyramid[r + 1][c]
        below_right = self.pyramid[r + 1][c + 1]
        return below_left is None and below_right is None

    def remove_pair(self, a: Tuple[int, int], b: Tuple[int, int]) -> bool:
        ar, ac = a
        br, bc = b
        if not (self.is_free(ar, ac) and self.is_free(br, bc)):
            return False
        ca = self.pyramid[ar][ac]
        cb = self.pyramid[br][bc]
        if ca is None or cb is None:
            return False
        if ca.value() + cb.value() == 13:
            self.pyramid[ar][ac] = None
            self.pyramid[br][bc] = None
            # scoring: 100 points per card removed
            self.score += 200
            return True
        return False

    def remove_with_waste(self, r: int, c: int) -> bool:
        if not self.waste:
            return False
        if not self.is_free(r, c):
            return False
        card = self.waste[-1]
        target = self.pyramid[r][c]
        if target is None:
            return False
        if card.value() + target.value() == 13:
            self.pyramid[r][c] = None
            self.waste.pop()
            self.score += 200
            return True
        return False

    def remove_king(self, r: int, c: int) -> bool:
        if not self.is_free(r, c):
            return False
        card = self.pyramid[r][c]
        if card and card.value() == 13:
            self.pyramid[r][c] = None
            self.score += 100
            return True
        return False

    def remove_waste_king(self) -> bool:
        if not self.waste:
            return False
        if self.waste[-1].value() == 13:
            self.waste.pop()
            self.score += 100
            return True
        return False

    def won(self) -> bool:
        return all(card is None for row in self.pyramid for card in row)

    def pyramid_str(self) -> str:
        lines = []
        for r, row in enumerate(self.pyramid):
            pad = ' ' * (6 - r) * 3
            parts = []
            for c, card in enumerate(row):
                if card is None:
                    parts.append('   .')
                else:
                    s = str(card)
                    parts.append(s.rjust(4))
            lines.append(pad + ''.join(parts))
        return '\n'.join(lines)

    def status_str(self) -> str:
        stock_count = len(self.stock)
        waste_top = str(self.waste[-1]) if self.waste else '  '
        return f"分數: {self.score} | 牌堆: {stock_count} | 棄牌頂端: {waste_top} | 重洗次數剩餘: {self.redeals_remaining}"
