import json
from solitaire.klondike import KlondikeGame


def test_roundtrip():
    g = KlondikeGame(draw_count=1)
    # perform some actions
    g.draw()
    g.move_waste_to_tableau(0)  # maybe fail, but fine
    g.move_waste_to_foundation()
    g.score += 42

    data = g.to_dict()
    with open('tmp_save.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)

    with open('tmp_save.json', 'r', encoding='utf-8') as f:
        loaded = json.load(f)

    g2 = KlondikeGame.from_dict(loaded)
    print('原始分數:', g.score)
    print('載入後分數:', g2.score)
    print('狀態:', g.status())


if __name__ == '__main__':
    test_roundtrip()
