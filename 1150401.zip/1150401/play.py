from pyramid_solitaire.pyramid import PyramidGame


def parse_coord(s: str):
    # expect format r,c with 0-based rows
    try:
        parts = s.split(',')
        if len(parts) != 2:
            return None
        r = int(parts[0])
        c = int(parts[1])
        return r, c
    except Exception:
        return None


def help_text():
    return (
        "Commands:\n"
        "  show                - 顯示金字塔、牌堆與棄牌\n"
        "  draw                - 從牌堆抽一張到棄牌\n"
        "  remove r1,c1 r2,c2  - 移除兩張金字塔卡，座標 0-based\n"
        "  removew r,c         - 用棄牌頂端與金字塔座標配對移除\n"
        "  removek r,c        - 移除該座標的 K(13) \n"
        "  removekw           - 移除棄牌頂端若為 K\n"
        "  help                - 顯示這個說明\n"
        "  quit                - 離開遊戲\n"
    )


def main():
    game = PyramidGame()
    print('Pyramid Solitaire — 簡易文字介面')
    print('輸入 help 查看指令')

    while True:
        cmd = input('> ').strip()
        if not cmd:
            continue
        parts = cmd.split()
        action = parts[0].lower()
        if action == 'show':
            print(game.pyramid_str())
            print(game.status_str())
            if game.won():
                print('你贏了!')
                break
        elif action == 'draw':
            # if stock empty but waste available and redeals left, inform user
            if not game.stock and game.waste and game.redeals_remaining > 0:
                print(f'牌堆空，將自動重洗棄牌回牌堆（剩餘重洗次數: {game.redeals_remaining}）')
            card = game.draw()
            if card:
                print('抽到:', card)
            else:
                print('牌堆已空且無重洗次數')
        elif action == 'remove' and len(parts) == 3:
            a = parse_coord(parts[1])
            b = parse_coord(parts[2])
            if a and b and game.remove_pair(a, b):
                print('移除成功')
            else:
                print('無法移除，確認座標且兩張皆為可移除狀態且點數合計13')
        elif action == 'removew' and len(parts) == 2:
            a = parse_coord(parts[1])
            if a and game.remove_with_waste(a[0], a[1]):
                print('移除成功（使用棄牌）')
            else:
                print('無法移除，確認棄牌或目標是否可移除')
        elif action == 'removek' and len(parts) == 2:
            a = parse_coord(parts[1])
            if a and game.remove_king(a[0], a[1]):
                print('移除 K 成功')
            else:
                print('無法移除 K')
        elif action == 'removekw' or action == 'removekw':
            if game.remove_waste_king():
                print('棄牌 K 已移除')
            else:
                print('棄牌頂端不是 K 或棄牌為空')
        elif action == 'help':
            print(help_text())
        elif action == 'quit':
            print('離開遊戲')
            break
        else:
            print('不明指令，輸入 help 查看可用指令')


if __name__ == '__main__':
    main()
